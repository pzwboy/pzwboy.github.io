===WineD3D for Windows===
DirectX 1-11 to OpenGL wrapper.

旧游戏不适应新系统或者32位游戏运行在64位系统是卡顿的一个解决方案

直接拷贝对应的dll到游戏主程序的文件夹下

==Instructions==
For DirectX 8 games:
d3d8.dll + libwine.dll + wined3d.dll

For DirectX 9 games:
d3d9.dll + libwine.dll + wined3d.dll

For DirectX 10 games:
d3d10.dll + d3d10core.dll + libwine.dll + wined3d.dll

For DirectX 11 games:
d3d11.dll + dxgi.dll + libwine.dll + wined3d.dll

For DirectX<=7 games:
ddraw.dll + libwine.dll + wined3d.dll
重命名 ddraw.dll 为ddfuk.dll，也可以是其他的5个字符长度的命名。
对游戏原有的.exe, .dll, .ren等文件使用二进制编辑软件搜索 ddraw.dll 字符并替换为 ddfuk.dll，有一个就换一个。

记住了：
不要拷贝任何文件到系统文件夹内（Windows\System32, Windows\SysWoW64）包括任何已记入系统环境的文件夹中

不合用的话，删掉对应的dll，不是百分百能解决每一个游戏的。

[K] 2023
